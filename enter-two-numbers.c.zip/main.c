#include<stdio.h>
int main()
{ 
    int x,y,z;
    printf("I am in section G2J");
    printf("Enter two numbers-%d,%d\n",x,y);
    scanf("%d %d",&x,&y);
    z = x + y;
    printf("sum of two numbers is -%d",z);
    return 0;
    }